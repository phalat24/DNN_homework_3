# Deep Neural Networks Homework 3

## Link to the solution

You can find the solution to this
problem [here](https://colab.research.google.com/github/phalat24/DNN_homework_3/blob/main/notebook.ipynb)
